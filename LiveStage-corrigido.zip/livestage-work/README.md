# LiveStage

Projeto web React + TypeScript criado com Lovable, TanStack Start, Tailwind e Supabase.

## Começar

É necessário um computador com Node.js e acesso ao projeto Supabase.

```sh
npm install
cp .env.example .env
# Preencha .env com as credenciais públicas do seu projeto Supabase
npm run dev
```

## Antes de testar

Leia `CORRECOES-LIVESTAGE.md` e aplique as migrações SQL em `supabase/migrations/` no projeto Supabase correto.

## Comandos de validação

```sh
npm run lint
npm run test
npm run build
```

## Limitação atual

O chat e a listagem de salas usam o Supabase, mas áudio/vídeo entre espectadores ainda precisa da integração de mídia em tempo real. O projeto não deve ser considerado um aplicativo de transmissão completo ou um APK pronto até que essa integração seja desenvolvida e testada.
