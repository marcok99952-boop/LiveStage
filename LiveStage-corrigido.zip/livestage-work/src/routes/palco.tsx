import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Mic, MicOff, Video, VideoOff, Hand, PhoneOff, ArrowLeft, Users, Send, SwitchCamera, Share2, X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/palco")({
  head: () => ({
    meta: [
      { title: "Sala ao vivo — LiveStage" },
      { name: "description", content: "Palco virtual com vídeo, áudio, chat e participantes." },
      { property: "og:title", content: "Sala ao vivo — LiveStage" },
      { property: "og:description", content: "Suba ao palco e participe da conversa." },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { live?: string | undefined } => ({ live: typeof s["live"] === "string" ? s["live"] : undefined }),
  component: Palco,
});

function Palco() {
  const { live } = Route.useSearch();
  const { user } = useAuth();
  const [liveTitle, setLiveTitle] = useState<string | null>(null);
  const [chatReady, setChatReady] = useState(false);
  const [liveStatus, setLiveStatus] = useState<string | null>(null);
  useEffect(() => {
    if (!live) {
      setLiveTitle(null);
      setLiveStatus(null);
      setChatReady(false);
      return;
    }
    let cancelled = false;
    supabase.from("lives").select("title, status").eq("id", live).maybeSingle().then(({ data, error }) => {
      if (cancelled) return;
      setLiveTitle(data?.title ?? null);
      setLiveStatus(data?.status ?? null);
      if (error) toast.error("Não foi possível carregar os dados desta sala.");
      if (!error && !data) toast.error("Esta sala não existe ou não está disponível.");
    });
    return () => { cancelled = true; };
  }, [live]);
  const [mic, setMic] = useState(false);
  const [cam, setCam] = useState(false);
  const [hand, setHand] = useState(false);
  const [msgs, setMsgs] = useState<Array<{ id?: string; u: string; t: string }>>([]);
  const [text, setText] = useState("");

  useEffect(() => {
    if (!live) {
      setMsgs([]);
      setChatReady(false);
      return;
    }
    let active = true;
    const loadMessages = async () => {
      const { data, error } = await supabase
        .from("live_messages")
        .select("id, display_name, content, created_at")
        .eq("live_id", live)
        .order("created_at", { ascending: true })
        .limit(100);
      if (!active) return;
      if (error) {
        toast.error("O chat ainda não está configurado. Aplique a migração do banco de dados.");
        setChatReady(false);
        return;
      }
      setMsgs((data ?? []).map((m) => ({ id: m.id, u: m.display_name, t: m.content })));
      setChatReady(true);
    };
    void loadMessages();
    const channel = supabase
      .channel(`live-chat-${live}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "live_messages", filter: `live_id=eq.${live}` }, (payload) => {
        const row = payload.new as { id: string; display_name: string; content: string };
        if (active) setMsgs((current) => current.some((m) => m.id === row.id) ? current : [...current, { id: row.id, u: row.display_name, t: row.content }].slice(-100));
      })
      .subscribe();
    return () => {
      active = false;
      void supabase.removeChannel(channel);
    };
  }, [live]);

  const [ask, setAsk] = useState(false);
  const [share, setShare] = useState(false);
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  useEffect(() => { if (live) setAsk(true); }, [live]);
  useEffect(() => { if (videoRef.current) videoRef.current.srcObject = stream; }, [stream]);
  useEffect(() => () => stream?.getTracks().forEach((t) => t.stop()), [stream]);

  async function openCamera(mode: "user" | "environment" = facing) {
    setAsk(false);
    if (!navigator.mediaDevices?.getUserMedia) { toast.error("Este aparelho não permite usar a câmera pelo navegador."); return; }
    try {
      stream?.getTracks().forEach((t) => t.stop());
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode }, audio: true });
      setStream(s); setFacing(mode); setCam(true); setMic(true);
    } catch {
      toast.error("Permissão negada. Libere a câmera e o microfone nas configurações do navegador.");
    }
  }
  function toggleMic() { const v = !mic; stream?.getAudioTracks().forEach((t) => (t.enabled = v)); setMic(v); }
  function toggleCam() {
    if (!stream) { void openCamera(); return; }
    const v = !cam; stream.getVideoTracks().forEach((t) => (t.enabled = v)); setCam(v);
  }
  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const shareText = `Estou ao vivo no LiveStage: ${liveTitle ?? "venha assistir"}`;
  const enc = encodeURIComponent;
  const shareLinks = [
    { name: "WhatsApp", href: `https://wa.me/?text=${enc(shareText + " " + shareUrl)}` },
    { name: "Telegram", href: `https://t.me/share/url?url=${enc(shareUrl)}&text=${enc(shareText)}` },
    { name: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${enc(shareUrl)}` },
    { name: "X / Twitter", href: `https://twitter.com/intent/tweet?text=${enc(shareText)}&url=${enc(shareUrl)}` },
  ];

  const ctrl = (on: boolean) => `grid h-12 w-12 place-items-center rounded-full transition-colors ${on ? "bg-primary text-primary-foreground" : "bg-card"}`;

  return (
    <div className="mx-auto flex min-h-screen max-w-2xl flex-col px-4 pb-28 pt-4">
      <div className="mb-3 flex items-center gap-3">
        <Link to="/" aria-label="Voltar"><ArrowLeft className="h-5 w-5" /></Link>
        <div className="flex-1">
          <p className="font-semibold">{liveTitle ?? "Prévia do palco"}</p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Users className="h-3 w-3" />
            {live ? (liveStatus === "setup" ? "Sala criada · vídeo ainda não conectado" : liveStatus === "live" ? "Marcada como ao vivo · vídeo não validado" : "Sala encerrada ou indisponível") : "Modo de demonstração"}
          </div>
        </div>
      </div>

      <div className="relative overflow-hidden rounded-2xl shadow-glow">
        {stream ? (
          <video ref={videoRef} autoPlay playsInline muted className={`aspect-[4/3] w-full bg-muted object-cover ${facing === "user" ? "-scale-x-100" : ""} ${cam ? "" : "opacity-0"}`} />
        ) : (
          <div className="flex aspect-[4/3] w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-slate-950 via-violet-950 to-slate-900 px-6 text-center">
            <Video className="h-12 w-12 text-violet-300" />
            <p className="text-lg font-semibold text-white">Prévia da transmissão</p>
            <p className="max-w-xs text-sm text-white/70">Sua câmera aparecerá aqui. Para transmitir para outras pessoas, ainda é necessário conectar o serviço de vídeo ao vivo.</p>
          </div>
        )}
        {stream && (
          <button onClick={() => openCamera(facing === "user" ? "environment" : "user")} aria-label="Trocar câmera" className="absolute right-2 top-2 grid h-9 w-9 place-items-center rounded-full bg-background/70"><SwitchCamera className="h-4 w-4" /></button>
        )}
        {stream && <span className="absolute bottom-2 left-2 rounded-full bg-background/70 px-2 py-0.5 text-xs">Prévia local</span>}
      </div>

      <div className="mt-3 rounded-xl border border-border bg-card p-3 text-center text-sm text-muted-foreground">
        Os participantes reais aparecerão aqui quando o serviço de transmissão estiver conectado.
      </div>

      <div className="mt-4 flex-1 space-y-2 rounded-2xl bg-card p-3">
        {!live && <p className="text-xs text-muted-foreground">Prévia do palco. Abra uma sala criada no aplicativo para acessar o chat real.</p>}
        {live && !chatReady && <p className="text-xs text-muted-foreground">Conectando ao chat… Se não funcionar, aplique a migração do banco indicada no arquivo de instruções.</p>}
        {live && !msgs.length && <p className="text-sm text-muted-foreground">Ainda não há mensagens. Seja o primeiro a conversar!</p>}
        {msgs.map((m, i) => (
          <p key={m.id ?? `${m.u}-${i}`} className="text-sm"><span className="font-semibold text-secondary">{m.u}</span> {m.t}</p>
        ))}
        <form
          className="flex gap-2 pt-2"
          onSubmit={async (e) => {
            e.preventDefault();
            const content = text.trim();
            if (!content) return;
            if (!live) {
              toast.error("Abra uma live pelo botão Criar live para usar o chat real.");
              return;
            }
            if (!user) {
              toast.error("Entre na sua conta para enviar mensagens.");
              return;
            }
            if (!chatReady) {
              toast.error("O chat ainda não está pronto. Verifique a configuração do banco.");
              return;
            }
            const displayName = user.user_metadata?.display_name || user.user_metadata?.full_name || user.email?.split("@")[0] || "Usuário";
            const { error } = await supabase.from("live_messages").insert({ live_id: live, user_id: user.id, display_name: displayName, content });
            if (error) {
              toast.error("Não foi possível enviar a mensagem.");
              return;
            }
            setText("");
          }}
        >
          <input value={text} onChange={(e) => setText(e.target.value)} maxLength={500} placeholder="Escreva no chat…" className="flex-1 rounded-xl bg-muted px-3 py-2 text-sm outline-none" aria-label="Mensagem do chat" />
          <button className="grid h-9 w-9 place-items-center rounded-xl bg-primary" aria-label="Enviar mensagem"><Send className="h-4 w-4" /></button>
        </form>
      </div>

      <div className="fixed inset-x-0 bottom-0 mx-auto flex max-w-2xl justify-around border-t border-border bg-sidebar/95 py-3 backdrop-blur">
        <button className={ctrl(mic)} onClick={toggleMic} aria-label="Microfone">{mic ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}</button>
        <button className={ctrl(cam)} onClick={toggleCam} aria-label="Câmera">{cam ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}</button>
        <button className={ctrl(hand)} onClick={() => setHand(!hand)} aria-label="Pedir para falar"><Hand className="h-5 w-5" /></button>
        <button className={ctrl(share)} onClick={() => setShare(true)} aria-label="Compartilhar"><Share2 className="h-5 w-5" /></button>
        <Link to="/" className="grid h-12 w-12 place-items-center rounded-full bg-destructive" aria-label="Sair"><PhoneOff className="h-5 w-5" /></Link>
      </div>

      {ask && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 px-6 backdrop-blur">
          <div className="w-full max-w-sm space-y-4 rounded-2xl bg-card p-6 text-center shadow-glow">
            <Video className="mx-auto h-10 w-10 text-primary" />
            <h2 className="text-lg font-semibold">Abrir a câmera?</h2>
            <p className="text-sm text-muted-foreground">A câmera e o microfone serão usados somente como prévia neste aparelho. Outras pessoas ainda não receberão seu áudio ou vídeo.</p>
            <button onClick={() => openCamera()} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground">Sim, abrir câmera</button>
            <button onClick={() => setAsk(false)} className="w-full rounded-xl border border-border py-3 text-sm">Agora não</button>
          </div>
        </div>
      )}

      {share && (
        <div className="fixed inset-0 z-50 flex items-end bg-background/70 backdrop-blur" onClick={() => setShare(false)}>
          <div className="mx-auto w-full max-w-2xl space-y-3 rounded-t-2xl bg-card p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between"><h2 className="font-semibold">Divulgar a live</h2><button onClick={() => setShare(false)} aria-label="Fechar"><X className="h-5 w-5" /></button></div>
            <div className="grid grid-cols-2 gap-2">
              {shareLinks.map((l) => (
                <a key={l.name} href={l.href} target="_blank" rel="noreferrer" className="rounded-xl bg-muted py-3 text-center text-sm font-medium">{l.name}</a>
              ))}
              <button onClick={() => { void navigator.clipboard?.writeText(shareUrl); toast.success("Link copiado! Cole no Instagram, TikTok ou Kwai."); }} className="col-span-2 rounded-xl bg-primary py-3 text-sm font-medium text-primary-foreground">Copiar link</button>
            </div>
            <p className="text-xs text-muted-foreground">Transmitir ao mesmo tempo no YouTube, TikTok, Instagram, Kwai e Facebook depende do serviço de transmissão (próxima etapa).</p>
          </div>
        </div>
      )}
    </div>
  );
}
