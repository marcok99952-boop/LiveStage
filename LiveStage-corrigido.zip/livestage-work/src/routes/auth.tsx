import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Lock, Eye, EyeOff, User } from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/livestage";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";
import hero from "@/assets/hero-stage.jpg";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — LiveStage" },
      { name: "description", content: "Entre ou crie sua conta LiveStage." },
      { property: "og:title", content: "Entrar — LiveStage" },
      { property: "og:description", content: "Acesse suas lives, palcos e comunidades." },
    ],
  }),
  component: AuthPage,
});

type Mode = "login" | "signup" | "forgot";
const field = "flex items-center gap-3 rounded-xl border border-input bg-card px-4 py-3";
const input = "flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground";

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Bem-vindo de volta!");
        navigate({ to: "/perfil" });
      } else if (mode === "signup") {
        if (password.length < 6) throw new Error("A senha precisa ter pelo menos 6 caracteres.");
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { display_name: name } },
        });
        if (error) throw error;
        toast.success("Conta criada! Confira seu e-mail para confirmar o cadastro.");
        setMode("login");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Enviamos um link de recuperação para seu e-mail.");
        setMode("login");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Algo deu errado.";
      const code = (err as { code?: string })?.code;
      let pt = msg;
      if (msg === "Invalid login credentials") pt = "E-mail ou senha incorretos.";
      else if (code === "weak_password" || /weak|pwned/i.test(msg)) pt = "Senha muito fraca ou já vazada na internet. Use uma senha mais forte (misture letras, números e símbolos).";
      else if (/not allowed|invalid.*email/i.test(msg)) pt = "Este e-mail não é válido. Use um e-mail real.";
      else if (/already registered|already exists/i.test(msg)) pt = "Este e-mail já tem conta. Faça login.";
      else if (/not confirmed/i.test(msg)) pt = "Confirme seu e-mail pelo link que enviamos antes de entrar.";
      else if (/rate limit|too many/i.test(msg)) pt = "Muitas tentativas. Aguarde alguns minutos e tente de novo.";
      toast.error(pt);
    } finally {
      setBusy(false);
    }
  }

  async function oauth(provider: "google" | "lovable") {
    const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin });
    if (r.error) { toast.error("Não foi possível entrar. Tente novamente."); return; }
    if (r.redirected) return;
    navigate({ to: "/perfil" });
  }

  const title = { login: "Entrar", signup: "Criar conta", forgot: "Recuperar senha" }[mode];

  return (
    <div className="relative mx-auto flex min-h-screen max-w-md flex-col justify-end overflow-hidden px-6 pb-10">
      <img src={hero} alt="" className="absolute inset-0 h-1/2 w-full object-cover opacity-60" />
      <div className="absolute inset-0 bg-fade" />
      <div className="relative flex flex-col items-center gap-3 pb-6">
        <Logo size="lg" />
        <h1 className="text-3xl font-bold">Live<span className="text-brand">Stage</span></h1>
        <p className="text-sm text-muted-foreground">{title}</p>
      </div>
      <form className="relative space-y-3" onSubmit={submit}>
        {mode === "signup" && (
          <label className={field}>
            <User className="h-4 w-4 text-muted-foreground" />
            <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Seu nome" className={input} />
          </label>
        )}
        <label className={field}>
          <Mail className="h-4 w-4 text-muted-foreground" />
          <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="E-mail" className={input} />
        </label>
        {mode !== "forgot" && (
          <label className={field}>
            <Lock className="h-4 w-4 text-muted-foreground" />
            <input required type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Senha" className={input} />
            <button type="button" onClick={() => setShow(!show)} aria-label="Mostrar senha">
              {show ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
            </button>
          </label>
        )}
        <button disabled={busy} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground shadow-glow disabled:opacity-60">
          {busy ? "Aguarde…" : mode === "forgot" ? "Enviar link" : title}
        </button>

        {mode !== "forgot" && (
          <>
            <button type="button" onClick={() => oauth("google")} className="w-full rounded-xl border border-border bg-card py-3 text-sm font-medium">
              Continuar com Google
            </button>
            <button type="button" className="lovable-auth-button w-full" onClick={() => oauth("lovable")}>
              Continue with Lovable
            </button>
          </>
        )}

        <div className="flex justify-between pt-2 text-sm">
          {mode === "login" ? (
            <>
              <button type="button" className="text-primary" onClick={() => setMode("forgot")}>Esqueceu sua senha?</button>
              <button type="button" className="text-muted-foreground" onClick={() => setMode("signup")}>Criar conta</button>
            </>
          ) : (
            <button type="button" className="text-primary" onClick={() => setMode("login")}>Já tenho conta — entrar</button>
          )}
        </div>
      </form>
    </div>
  );
}
