import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Lock } from "lucide-react";
import { toast } from "sonner";
import { Logo } from "@/components/livestage";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Nova senha — LiveStage" },
      { name: "description", content: "Defina uma nova senha para sua conta LiveStage." },
      { property: "og:title", content: "Nova senha — LiveStage" },
      { property: "og:description", content: "Recupere o acesso à sua conta." },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) { toast.error("A senha precisa ter pelo menos 6 caracteres."); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { toast.error("O link expirou ou é inválido. Peça um novo."); return; }
    toast.success("Senha atualizada!");
    navigate({ to: "/perfil" });
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-6 px-6">
      <div className="flex flex-col items-center gap-3">
        <Logo size="lg" />
        <h1 className="text-2xl font-bold">Defina sua nova senha</h1>
      </div>
      <form onSubmit={submit} className="space-y-3">
        <label className="flex items-center gap-3 rounded-xl border border-input bg-card px-4 py-3">
          <Lock className="h-4 w-4 text-muted-foreground" />
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Nova senha" className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
        </label>
        <button disabled={busy} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground shadow-glow disabled:opacity-60">
          {busy ? "Salvando…" : "Salvar nova senha"}
        </button>
      </form>
    </div>
  );
}
