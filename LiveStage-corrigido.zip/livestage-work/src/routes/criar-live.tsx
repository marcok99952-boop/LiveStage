import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Radio } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/criar-live")({
  head: () => ({
    meta: [
      { title: "Criar live — LiveStage" },
      { name: "description", content: "Inicie uma nova transmissão ao vivo no LiveStage." },
      { property: "og:title", content: "Criar live — LiveStage" },
      { property: "og:description", content: "Abra seu palco e comece a transmitir." },
    ],
  }),
  component: CriarLive,
});

const cats = ["Aulas", "Debates", "Música", "Games", "Comunidade"];

function CriarLive() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>("Aulas");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);

  async function start(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    if (!user) return;
    if (title.trim().length < 3) { toast.error("O título precisa ter pelo menos 3 letras."); return; }
    setBusy(true);
    const { data, error } = await supabase
      .from("lives")
      .insert({ host_id: user.id, title: title.trim(), category, description: description.trim() || null, status: "setup" })
      .select("id")
      .single();
    setBusy(false);
    if (error) { toast.error("Não foi possível iniciar a live. Tente novamente."); return; }
    toast.success("Sala criada. A transmissão de vídeo ainda precisa ser conectada.");
    navigate({ to: "/palco", search: { live: data.id } });
  }

  return (
    <div className="mx-auto min-h-screen max-w-md px-6 py-6">
      <Link to="/" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Voltar</Link>
      <h1 className="mb-6 text-2xl font-bold">Criar live</h1>
      {loading ? (
        <p className="text-muted-foreground">Carregando…</p>
      ) : !user ? (
        <div className="space-y-4 rounded-2xl bg-card p-5 text-center">
          <p>Entre na sua conta para iniciar uma live.</p>
          <Link to="/auth" className="block rounded-xl bg-primary py-3 font-medium text-primary-foreground">Entrar ou criar conta</Link>
        </div>
      ) : (
        <form onSubmit={start} className="space-y-4">
          <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} placeholder="Título da live" className="w-full rounded-xl border border-input bg-card px-4 py-3 text-sm outline-none" />
          <div className="flex flex-wrap gap-2">
            {cats.map((c) => (
              <button type="button" key={c} onClick={() => setCategory(c)} className={`rounded-full border px-3 py-1.5 text-xs ${category === c ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card"}`}>{c}</button>
            ))}
          </div>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Descrição (opcional)" className="w-full rounded-xl border border-input bg-card px-4 py-3 text-sm outline-none" />
          <button disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-medium text-primary-foreground shadow-glow disabled:opacity-60">
            <Radio className="h-4 w-4" /> {busy ? "Iniciando…" : "Iniciar live"}
          </button>
        </form>
      )}
    </div>
  );
}
