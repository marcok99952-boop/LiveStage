import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Search, Bell, Plus, GraduationCap, MessagesSquare, Music, Gamepad2, Crown } from "lucide-react";
import { AppShell, Logo, Avatar } from "@/components/livestage";
import hero from "@/assets/hero-stage.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LiveStage — Lives interativas e palcos virtuais" },
      { name: "description", content: "Assista, participe e crie lives, aulas, debates e comunidades em tempo real." },
      { property: "og:title", content: "LiveStage — Lives interativas" },
      { property: "og:description", content: "Seu espaço. Sua voz. Seu palco." },
    ],
  }),
  component: Index,
});

const categories = [
  { label: "Aulas", icon: GraduationCap },
  { label: "Debates", icon: MessagesSquare },
  { label: "Música", icon: Music },
  { label: "Games", icon: Gamepad2 },
  { label: "Premium", icon: Crown },
];

type LiveItem = { id: string; title: string; category: string; description: string | null; created_at: string; host_id: string; status: string };

function Splash({ done }: { done: boolean }) {
  return (
    <div className={`fixed inset-0 z-50 grid place-items-center bg-background transition-opacity duration-700 ${done ? "pointer-events-none opacity-0" : "opacity-100"}`}>
      <div className="flex flex-col items-center gap-5 animate-in fade-in zoom-in-90 duration-700">
        <div className="animate-float"><Logo size="lg" /></div>
        <h1 className="text-4xl font-bold">Live<span className="text-brand">Stage</span></h1>
        <p className="text-muted-foreground">Seu espaço. Sua voz. Seu palco.</p>
      </div>
    </div>
  );
}

function Index() {
  const [done, setDone] = useState(false);
  const [lives, setLives] = useState<LiveItem[]>([]);
  const [livesLoading, setLivesLoading] = useState(true);
  const [livesError, setLivesError] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setDone(true), 900);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    let active = true;
    async function loadLives() {
      const { data, error } = await supabase
        .from("lives")
        .select("id, title, category, description, created_at, host_id, status")
        .in("status", ["setup", "live"])
        .order("created_at", { ascending: false })
        .limit(20);
      if (!active) return;
      setLivesLoading(false);
      if (error) {
        setLivesError(true);
        return;
      }
      setLives(data ?? []);
    }
    void loadLives();
    const channel = supabase
      .channel("home-live-list")
      .on("postgres_changes", { event: "*", schema: "public", table: "lives" }, () => { void loadLives(); })
      .subscribe();
    return () => {
      active = false;
      void supabase.removeChannel(channel);
    };
  }, []);

  return (
    <>
      <Splash done={done} />
      <AppShell
        header={
          <div className="flex items-center justify-between">
            <Logo />
            <div className="flex gap-3 text-muted-foreground">
              <Search className="h-5 w-5" />
              <Link to="/notificacoes"><Bell className="h-5 w-5" /></Link>
            </div>
          </div>
        }
      >
        <h2 className="mb-3 font-semibold">Live em destaque</h2>
        <div className="relative overflow-hidden rounded-2xl shadow-glow">
          <img src={hero} alt="Palco virtual com luzes neon" width={1280} height={720} className="aspect-video w-full object-cover" />
          <div className="absolute inset-0 bg-fade" />
          <div className="absolute bottom-3 left-3 right-3">
            <p className="mb-1 font-semibold">Seu próximo palco começa aqui</p>
            <p className="text-xs text-white/80">Crie uma sala e convide pessoas para participar.</p>
          </div>
        </div>

        <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
          {categories.map(({ label, icon: Icon }) => (
            <span key={label} className="flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs">
              <Icon className="h-3.5 w-3.5 text-primary" /> {label}
            </span>
          ))}
        </div>

        <div className="mb-3 mt-6 flex items-center justify-between">
          <h2 className="font-semibold">Salas disponíveis</h2>
          <span className="text-xs text-primary">Ver todas</span>
        </div>
        <ul className="space-y-3">
          {livesLoading ? (
            <li className="rounded-2xl bg-card p-4 text-sm text-muted-foreground">Carregando salas…</li>
          ) : livesError ? (
            <li className="rounded-2xl bg-card p-4 text-sm text-muted-foreground">Não foi possível carregar as salas. Verifique a conexão com o banco de dados.</li>
          ) : lives.length === 0 ? (
            <li className="rounded-2xl bg-card p-4 text-sm text-muted-foreground">Ainda não há salas disponíveis. Seja o primeiro a criar uma live.</li>
          ) : lives.map((l) => (
            <li key={l.id}>
              <Link to="/palco" search={{ live: l.id }} className="flex items-center gap-3 rounded-2xl bg-card p-3 transition-colors hover:bg-accent">
                <Avatar name={l.title} className="h-12 w-12" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{l.title}</p>
                  <p className="text-xs text-muted-foreground">{l.category}{l.description ? ` · ${l.description}` : ""}</p>
                </div>
                <span className="rounded-full border border-primary/40 px-2 py-1 text-[10px] text-primary">{l.status === "live" ? "Ao vivo" : "Sala criada"}</span>
              </Link>
            </li>
          ))}
        </ul>

        <Link to="/criar-live" className="mt-6 flex items-center justify-center gap-2 rounded-2xl bg-primary py-3 font-medium text-primary-foreground shadow-glow transition-transform active:scale-95">
          <Plus className="h-4 w-4" /> Criar Live
        </Link>
      </AppShell>
    </>
  );
}
