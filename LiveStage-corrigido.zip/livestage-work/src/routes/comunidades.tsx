import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search, GraduationCap, Cpu, Music, Sprout, Gamepad2 } from "lucide-react";
import { AppShell } from "@/components/livestage";

export const Route = createFileRoute("/comunidades")({
  head: () => ({
    meta: [
      { title: "Comunidades — LiveStage" },
      { name: "description", content: "Encontre comunidades, eventos e publicações." },
      { property: "og:title", content: "Comunidades — LiveStage" },
      { property: "og:description", content: "Participe de comunidades ativas." },
    ],
  }),
  component: Comunidades,
});

const list = [
  { name: "Estudos e Aprendizado", m: "12,4 mil", icon: GraduationCap },
  { name: "Tecnologia e Inovação", m: "8,7 mil", icon: Cpu },
  { name: "Música e Entretenimento", m: "15,2 mil", icon: Music },
  { name: "Desenvolvimento Pessoal", m: "6,3 mil", icon: Sprout },
  { name: "Games e E-sports", m: "9,8 mil", icon: Gamepad2 },
];
const tabs = ["Em alta", "Meus grupos", "Descobrir"];

function Comunidades() {
  const [tab, setTab] = useState(tabs[0]);
  const [joined, setJoined] = useState<string[]>([]);
  return (
    <AppShell header={<h1 className="text-xl font-bold">Comunidades</h1>}>
      <label className="flex items-center gap-2 rounded-xl bg-card px-3 py-2.5">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input placeholder="Buscar comunidades…" className="flex-1 bg-transparent text-sm outline-none" />
      </label>
      <div className="my-4 flex gap-2">
        {tabs.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-full px-3 py-1.5 text-xs ${tab === t ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground"}`}>{t}</button>
        ))}
      </div>
      <ul className="space-y-3">
        {list.map(({ name, m, icon: Icon }) => {
          const on = joined.includes(name);
          return (
            <li key={name} className="flex items-center gap-3 rounded-2xl bg-card p-3">
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand"><Icon className="h-6 w-6" /></span>
              <div className="flex-1">
                <p className="text-sm font-medium">{name}</p>
                <p className="text-xs text-muted-foreground">{m} membros</p>
              </div>
              <button onClick={() => setJoined(on ? joined.filter((j) => j !== name) : [...joined, name])} className={`rounded-lg px-3 py-1.5 text-xs font-medium ${on ? "border border-primary" : "bg-primary text-primary-foreground"}`}>
                {on ? "Membro" : "Entrar"}
              </button>
            </li>
          );
        })}
      </ul>
    </AppShell>
  );
}
