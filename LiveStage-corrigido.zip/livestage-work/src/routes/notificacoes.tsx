import { createFileRoute } from "@tanstack/react-router";
import { AppShell, Avatar } from "@/components/livestage";

export const Route = createFileRoute("/notificacoes")({
  head: () => ({
    meta: [
      { title: "Notificações — LiveStage" },
      { name: "description", content: "Convites, mensagens e alertas das suas lives." },
      { property: "og:title", content: "Notificações — LiveStage" },
      { property: "og:description", content: "Fique por dentro de tudo que acontece." },
    ],
  }),
  component: Notificacoes,
});

const items = [
  { who: "Mariana Souza", what: "convidou você para subir ao palco", when: "agora" },
  { who: "Tecnologia e Inovação", what: "agendou um evento para amanhã às 19h", when: "5 min" },
  { who: "Carlos Lima", what: "começou a seguir você", when: "1 h" },
  { who: "Ana Costa", what: "enviou uma mensagem", when: "3 h" },
];

function Notificacoes() {
  return (
    <AppShell header={<h1 className="text-xl font-bold">Notificações</h1>}>
      <ul className="space-y-2">
        {items.map((n) => (
          <li key={n.who + n.when} className="flex items-center gap-3 rounded-2xl bg-card p-3">
            <Avatar name={n.who} />
            <p className="flex-1 text-sm"><span className="font-semibold">{n.who}</span> <span className="text-muted-foreground">{n.what}</span></p>
            <span className="text-xs text-muted-foreground">{n.when}</span>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
