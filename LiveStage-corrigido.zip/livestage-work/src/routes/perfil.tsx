import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Crown, Wallet, PlayCircle, Users, Settings, HelpCircle, ShieldCheck, ChevronRight, LogOut } from "lucide-react";
import { toast } from "sonner";
import { AppShell, Avatar } from "@/components/livestage";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Meu perfil — LiveStage" },
      { name: "description", content: "Seu perfil, plano, lives e configurações." },
      { property: "og:title", content: "Meu perfil — LiveStage" },
      { property: "og:description", content: "Gerencie sua presença no LiveStage." },
    ],
  }),
  component: Perfil,
});

const menu = [
  { label: "Meu plano", icon: Crown, extra: "Gratuito" },
  { label: "Carteira", icon: Wallet, extra: "R$ 0,00" },
  { label: "Minhas lives", icon: PlayCircle },
  { label: "Comunidades", icon: Users },
  { label: "Configurações", icon: Settings },
  { label: "Painel administrativo", icon: ShieldCheck },
  { label: "Ajuda e suporte", icon: HelpCircle },
];

type Profile = { display_name: string | null; username: string | null; bio: string | null };

function Perfil() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<Profile>({ display_name: "", username: "", bio: "" });

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("display_name, username, bio").eq("id", user.id).maybeSingle().then(({ data }) => {
      setProfile(data);
      if (data) setForm(data);
    });
  }, [user]);

  async function save() {
    if (!user) return;
    const username = form.username?.trim().toLowerCase() || null;
    if (username && !/^[a-z0-9_]{3,20}$/.test(username)) { toast.error("Usuário: 3 a 20 letras, números ou _."); return; }
    const payload = { display_name: form.display_name?.trim().slice(0, 60) || null, username, bio: form.bio?.trim().slice(0, 300) || null };
    const { error } = await supabase.from("profiles").update(payload).eq("id", user.id);
    if (error) { toast.error(error.code === "23505" ? "Esse nome de usuário já está em uso." : "Não foi possível salvar."); return; }
    setProfile(payload);
    setEditing(false);
    toast.success("Perfil atualizado!");
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (loading) return <AppShell><p className="text-muted-foreground">Carregando…</p></AppShell>;
  if (!user)
    return (
      <AppShell>
        <div className="mt-20 flex flex-col items-center gap-4 text-center">
          <p className="text-lg font-semibold">Entre para ver seu perfil</p>
          <Link to="/auth" className="rounded-xl bg-primary px-6 py-3 font-medium text-primary-foreground shadow-glow">Entrar ou criar conta</Link>
        </div>
      </AppShell>
    );

  const name = profile?.display_name || user.email || "Usuário";
  const inputCls = "w-full rounded-xl border border-input bg-card px-4 py-2.5 text-sm outline-none";

  return (
    <AppShell>
      <div className="flex items-center gap-4">
        <Avatar name={name} className="h-20 w-20 text-2xl ring-4 ring-primary/40" />
        <div className="min-w-0">
          <p className="truncate text-lg font-semibold">{name}</p>
          <p className="text-sm text-muted-foreground">{profile?.username ? `@${profile.username}` : user.email}</p>
        </div>
      </div>
      {profile?.bio && <p className="mt-3 text-sm text-muted-foreground">{profile.bio}</p>}
      <div className="my-5 grid grid-cols-3 rounded-2xl bg-card py-3 text-center">
        {[["0", "Seguidores"], ["0", "Seguindo"], ["0", "Lives"]].map(([n, l]) => (
          <div key={l}><p className="font-semibold">{n}</p><p className="text-xs text-muted-foreground">{l}</p></div>
        ))}
      </div>

      {editing ? (
        <div className="mb-5 space-y-3">
          <input className={inputCls} placeholder="Nome de exibição" value={form.display_name ?? ""} onChange={(e) => setForm({ ...form, display_name: e.target.value })} />
          <input className={inputCls} placeholder="Nome de usuário" value={form.username ?? ""} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          <textarea className={inputCls} rows={3} placeholder="Biografia" value={form.bio ?? ""} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
          <div className="flex gap-2">
            <button onClick={save} className="flex-1 rounded-xl bg-primary py-2.5 text-sm font-medium text-primary-foreground">Salvar</button>
            <button onClick={() => setEditing(false)} className="flex-1 rounded-xl bg-card py-2.5 text-sm">Cancelar</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setEditing(true)} className="mb-5 block w-full rounded-xl bg-card py-2.5 text-center text-sm font-medium">Editar perfil</button>
      )}

      <ul className="divide-y divide-border rounded-2xl bg-card">
        {menu.map(({ label, icon: Icon, extra }) => (
          <li key={label} className="flex items-center gap-3 px-4 py-3.5 text-sm">
            <Icon className="h-5 w-5 text-muted-foreground" />
            <span className="flex-1">{label}</span>
            {extra ? <span className="text-muted-foreground">{extra}</span> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
          </li>
        ))}
        <li>
          <button onClick={signOut} className="flex w-full items-center gap-3 px-4 py-3.5 text-sm text-destructive">
            <LogOut className="h-5 w-5" /> Sair
          </button>
        </li>
      </ul>
    </AppShell>
  );
}
