import { Link } from "@tanstack/react-router";
import { Home, Mic, Users, Bell, User, Play } from "lucide-react";
import type { ReactNode } from "react";

export function Logo({ size = "md" }: { size?: "md" | "lg" }) {
  const big = size === "lg";
  return (
    <div className="flex items-center gap-2">
      <span className={`grid place-items-center rounded-xl bg-brand shadow-glow ${big ? "h-20 w-20 rounded-3xl" : "h-8 w-8"}`}>
        <Play className={`fill-primary-foreground text-primary-foreground ${big ? "h-10 w-10" : "h-4 w-4"}`} />
      </span>
      {!big && (
        <span className="text-lg font-bold">
          Live<span className="text-brand">Stage</span>
        </span>
      )}
    </div>
  );
}

export function LiveBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-live px-2 py-0.5 text-[10px] font-semibold text-primary-foreground">
      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary-foreground" /> AO VIVO
    </span>
  );
}

const tabs = [
  { to: "/", label: "Início", icon: Home },
  { to: "/palco", label: "Palco", icon: Mic },
  { to: "/comunidades", label: "Comunidades", icon: Users },
  { to: "/notificacoes", label: "Notificações", icon: Bell },
  { to: "/perfil", label: "Perfil", icon: User },
] as const;

export function AppShell({ children, header }: { children: ReactNode; header?: ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen max-w-2xl flex-col bg-background">
      {header && <header className="sticky top-0 z-20 border-b border-border bg-background/90 px-4 py-3 backdrop-blur">{header}</header>}
      <main className="flex-1 px-4 pb-28 pt-4">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-2xl border-t border-border bg-sidebar/95 backdrop-blur">
        <ul className="grid grid-cols-5">
          {tabs.map(({ to, label, icon: Icon }) => (
            <li key={to}>
              <Link
                to={to}
                activeOptions={{ exact: to === "/" }}
                className="flex flex-col items-center gap-1 py-2.5 text-[10px] text-muted-foreground transition-colors data-[status=active]:text-primary"
              >
                <Icon className="h-5 w-5" />
                {label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}

export function Avatar({ name, className = "h-10 w-10" }: { name: string; className?: string }) {
  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("");
  return <span className={`grid shrink-0 place-items-center rounded-full bg-brand text-sm font-semibold text-primary-foreground ${className}`}>{initials}</span>;
}
