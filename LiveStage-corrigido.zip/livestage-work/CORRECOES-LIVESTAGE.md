# LiveStage — correções e estado do projeto

## Alterações feitas nesta revisão

- A tela inicial agora carrega salas reais da tabela `lives` do Supabase, em vez de mostrar lives e contagens de espectadores fictícias.
- A lista de salas é atualizada quando a tabela recebe alterações em tempo real.
- A navegação da tela inicial passa o identificador real da sala para o palco.
- Ao criar uma sala, o aplicativo grava `status = 'setup'`, em vez de afirmar que já existe uma transmissão ao vivo.
- A interface do palco não exibe mais apresentadora, participantes, quantidade de espectadores ou mensagens de exemplo como se fossem reais.
- A tela deixa claro que a câmera e o microfone são apenas uma prévia local até a integração de mídia estar pronta.
- O chat usa a tabela `live_messages`, carrega o histórico e recebe mensagens novas por Supabase Realtime.
- Foi incluída uma migração para permitir o estado `setup` e torná-lo o estado padrão de novas salas.
- O arquivo `.env` original não é distribuído. Use `.env.example` e coloque suas próprias credenciais localmente.

## Migrações SQL que precisam ser aplicadas no Supabase

Execute no SQL Editor do projeto, nesta ordem:

1. `supabase/migrations/20261028220000_live_messages.sql`
2. `supabase/migrations/20261028220500_live_status_setup.sql`

Se o projeto Supabase ainda não tiver a tabela `public.lives`, aplique primeiro a migração original que cria essa tabela (`drizzle/migrations/0001_migration.sql`) ou use o histórico de migrações equivalente do projeto. Não execute migrações de um banco de produção sem conferir antes o esquema atual.

## Configuração local

1. Copie `.env.example` para `.env`.
2. Preencha as variáveis com URL e chave pública do seu próprio projeto Supabase.
3. Instale as dependências com `npm install`.
4. Rode `npm run dev` para abrir localmente.
5. Rode `npm run build` e `npm run lint` antes de publicar.

## O que ainda NÃO está pronto

- A transmissão de áudio e vídeo entre diferentes aparelhos ainda não está implementada.
- O contador de espectadores, participantes reais, pedido para falar e moderação ainda não estão conectados ao backend.
- Comunidades, notificações e pagamentos ainda precisam de implementação real.
- Este pacote não é um APK e ainda não foi validado por uma compilação completa neste ambiente.

## Próxima etapa recomendada

Integrar um serviço de mídia em tempo real (por exemplo, LiveKit) com tokens de sala emitidos por backend seguro. Só então a sala deve mudar de `setup` para `live`, após a confirmação da conexão de mídia.
