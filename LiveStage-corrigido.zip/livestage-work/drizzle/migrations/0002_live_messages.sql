-- Chat persistente por sala. Execute esta migração no banco Supabase do projeto.
CREATE TABLE IF NOT EXISTS public.live_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_id uuid NOT NULL REFERENCES public.lives(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 80),
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 500),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS live_messages_live_created_idx
  ON public.live_messages (live_id, created_at);

ALTER TABLE public.live_messages ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON public.live_messages TO authenticated;
GRANT ALL ON public.live_messages TO service_role;

DROP POLICY IF EXISTS "Messages visible to signed-in users" ON public.live_messages;
CREATE POLICY "Messages visible to signed-in users"
  ON public.live_messages FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "Users send messages as themselves" ON public.live_messages;
CREATE POLICY "Users send messages as themselves"
  ON public.live_messages FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.lives WHERE lives.id = live_id));

-- Supabase Realtime publica INSERTs para o chat.
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime')
     AND NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'live_messages') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_messages;
  END IF;
END $$;
