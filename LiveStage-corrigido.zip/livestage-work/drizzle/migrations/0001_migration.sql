CREATE TABLE public.lives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  host_id uuid NOT NULL,
  title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
  category text NOT NULL DEFAULT 'Comunidade',
  description text,
  status text NOT NULL DEFAULT 'live' CHECK (status IN ('live','ended')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.lives TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lives TO authenticated;
GRANT ALL ON public.lives TO service_role;
ALTER TABLE public.lives ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view lives" ON public.lives FOR SELECT USING (true);
CREATE POLICY "Hosts create own lives" ON public.lives FOR INSERT TO authenticated WITH CHECK (auth.uid() = host_id);
CREATE POLICY "Hosts update own lives" ON public.lives FOR UPDATE TO authenticated USING (auth.uid() = host_id);
CREATE POLICY "Hosts delete own lives" ON public.lives FOR DELETE TO authenticated USING (auth.uid() = host_id);