-- Não marcar uma sala como "ao vivo" antes de existir uma conexão de mídia.
ALTER TABLE public.lives DROP CONSTRAINT IF EXISTS lives_status_check;
ALTER TABLE public.lives
  ADD CONSTRAINT lives_status_check CHECK (status IN ('setup', 'live', 'ended'));
ALTER TABLE public.lives ALTER COLUMN status SET DEFAULT 'setup';
